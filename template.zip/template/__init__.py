from electroncash.i18n import _

fullname = 'template'
description = _('Plugin template')
available_for = ['qt']
